#!/usr/bin/env python3

import argparse
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(
        description="Train GLACE with the CoStaR coordinate regression module."
    )
    parser.add_argument("scene", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--config",
        type=Path,
        default=ROOT / "configs" / "glace_default.json",
    )
    parser.add_argument(
        "--extra",
        nargs=argparse.REMAINDER,
        default=[],
        help="Additional arguments forwarded to GLACE train_ace.py.",
    )
    args = parser.parse_args()

    with args.config.open("r", encoding="utf-8") as f:
        cfg = json.load(f)

    args.output.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "torchrun",
        "--standalone",
        "--nnodes", "1",
        "--nproc-per-node", str(cfg.get("nproc_per_node", 1)),
        str(ROOT / "glace" / "train_ace.py"),
        str(args.scene),
        str(args.output),
        "--max_iterations", str(cfg["max_iterations"]),
        "--num_head_blocks", str(cfg["num_head_blocks"]),
        "--head_channels", str(cfg["head_channels"]),
        "--mlp_ratio", str(cfg["mlp_ratio"]),
        "--global_feat", str(cfg["global_feat"]),
        "--feat_name", str(cfg["feat_name"]),
        "--feat_noise_std", str(cfg["feat_noise_std"]),
    ]

    cmd.extend(args.extra)

    print("Running:")
    print(" ".join(cmd))
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
