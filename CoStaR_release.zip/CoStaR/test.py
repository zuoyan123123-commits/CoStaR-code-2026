#!/usr/bin/env python3

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate a GLACE + CoStaR scene coordinate regressor."
    )
    parser.add_argument("scene", type=Path)
    parser.add_argument("model", type=Path)
    parser.add_argument("--session", default="costar")
    parser.add_argument(
        "--extra",
        nargs=argparse.REMAINDER,
        default=[],
        help="Additional arguments forwarded to GLACE test_ace.py.",
    )
    args = parser.parse_args()

    cmd = [
        sys.executable,
        str(ROOT / "glace" / "test_ace.py"),
        str(args.scene),
        str(args.model),
        "--session",
        args.session,
    ]

    cmd.extend(args.extra)

    print("Running:")
    print(" ".join(cmd))
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
