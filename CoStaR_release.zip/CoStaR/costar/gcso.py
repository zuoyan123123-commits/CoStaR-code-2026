import torch
import torch.nn as nn
import torch.nn.functional as F


class GeometryCalibratedCoordinateStabilityObjective(nn.Module):
    """
    Geometry-Calibrated Coordinate Stability Objective (GCSO).

    This module contains only the CoStaR-specific objective terms.
    The backbone-specific reprojection losses are supplied externally.
    """

    def __init__(
        self,
        lambda_refine=1.0,
        lambda_unc=0.01,
        lambda_delta=0.02,
        delta_threshold=0.05,
        ramp_iterations=3000,
    ):
        super().__init__()

        self.lambda_refine = lambda_refine
        self.lambda_unc = lambda_unc
        self.lambda_delta = lambda_delta
        self.delta_threshold = delta_threshold
        self.ramp_iterations = ramp_iterations

    def forward(
        self,
        loss_coarse,
        loss_refined,
        reprojection_error,
        sigma,
        coarse_coords,
        refined_coords,
        iteration,
    ):
        """
        Args
        ----
        loss_coarse:
            Backbone-specific loss of coarse coordinates.

        loss_refined:
            Backbone-specific loss of refined coordinates.

        reprojection_error:
            Per-location geometric error corresponding to coarse prediction.

        sigma:
            Predicted uncertainty [B,1,H,W] or compatible flattened shape.

        coarse_coords / refined_coords:
            [B,3,H,W]

        iteration:
            Current training iteration.
        """

        reproj_log = torch.log1p(
            reprojection_error.detach().clamp(max=1000)
        )

        sigma_safe = sigma.clamp(min=1e-6)

        loss_unc = (
            sigma_safe.log()
            + reproj_log / sigma_safe
        ).mean()

        delta = (
            refined_coords.float()
            - coarse_coords.detach().float()
        )

        delta_norm = torch.sqrt(
            torch.sum(
                delta * delta,
                dim=1,
                keepdim=True,
            )
            + 1e-8
        )

        loss_delta = F.relu(
            delta_norm - self.delta_threshold
        ).mean()

        if self.ramp_iterations > 0:
            ramp = min(
                1.0,
                max(
                    0.0,
                    float(iteration)
                    / float(self.ramp_iterations),
                ),
            )
        else:
            ramp = 1.0

        total = (
            loss_coarse
            + self.lambda_refine
            * ramp
            * loss_refined
            + self.lambda_unc
            * loss_unc
            + self.lambda_delta
            * loss_delta
        )

        return {
            "loss": total,
            "loss_coarse": loss_coarse,
            "loss_refined": loss_refined,
            "loss_uncertainty": loss_unc,
            "loss_delta": loss_delta,
            "refine_ramp": ramp,
        }
