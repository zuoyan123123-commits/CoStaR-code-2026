import torch
import torch.nn as nn

from .cdsm import CoordinateDirectionalSpatialMixing


class ReliabilityGuidedResidualRefinement(nn.Module):
    """
    Reliability-Guided Residual Refinement (RGRR).

    Inputs:
        features:
            feature tensor [B, C, H, W]

        coarse_coords:
            coarse coordinate predictions [B, 3, H, W]

    Outputs:
        refined_coords
        sigma
        reliability
        residual
    """

    def __init__(
        self,
        channels,
        refine_channels=128,
        temperature=3.0,
        sigma_eps=0.01,
        sigma_max=10.0,
    ):
        super().__init__()

        self.temperature = temperature
        self.sigma_eps = sigma_eps
        self.sigma_max = sigma_max

        # Reliability / uncertainty estimation.
        self.uncertainty = nn.Sequential(
            nn.Conv2d(channels, 128, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 1, 1),
        )

        self.softplus = nn.Softplus(beta=1.0)

        nn.init.zeros_(self.uncertainty[2].weight)
        nn.init.constant_(self.uncertainty[2].bias, 0.54)

        # Residual coordinate refinement.
        self.refinement = nn.Sequential(
            nn.Conv2d(
                channels,
                refine_channels,
                1,
                bias=False,
            ),
            nn.GroupNorm(
                8,
                refine_channels,
                eps=1e-4,
            ),
            nn.ReLU6(inplace=True),

            CoordinateDirectionalSpatialMixing(
                refine_channels,
                refine_channels,
                kernel_size=3,
            ),

            nn.GroupNorm(
                8,
                refine_channels,
                eps=1e-4,
            ),
            nn.ReLU6(inplace=True),

            nn.Conv2d(
                refine_channels,
                3,
                1,
            ),

            nn.Hardtanh(
                min_val=-2.0,
                max_val=2.0,
                inplace=True,
            ),
        )

        # Start from near-zero residual correction.
        nn.init.zeros_(self.refinement[6].weight)
        nn.init.zeros_(self.refinement[6].bias)

    def forward(self, features, coarse_coords):
        # Stop coordinate-path gradients from modifying reliability estimation.
        sigma = (
            self.softplus(
                self.uncertainty(features.detach())
            )
            + self.sigma_eps
        )

        sigma = sigma.clamp(
            max=self.sigma_max
        )

        # High uncertainty -> low reliability.
        reliability = torch.sigmoid(
            -sigma.detach() / self.temperature
        )

        weighted_features = (
            features * reliability
        )

        residual = self.refinement(
            weighted_features
        )

        refined_coords = (
            coarse_coords + residual
        )

        return {
            "refined": refined_coords,
            "coarse": coarse_coords,
            "sigma": sigma,
            "reliability": reliability,
            "residual": residual,
        }
