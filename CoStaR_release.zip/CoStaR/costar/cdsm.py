import torch
import torch.nn as nn


class CoordinateDirectionalSpatialMixing(nn.Module):
    """
    Coordinate Directional Spatial Mixing Module (C-DSM).

    Multi-directional spatial interaction with asymmetric convolutions.
    """

    def __init__(self, in_channels, out_channels=None, kernel_size=3, stride=1):
        super().__init__()

        if out_channels is None:
            out_channels = in_channels

        if out_channels % 4 != 0:
            raise ValueError("out_channels must be divisible by 4.")

        k = kernel_size

        pads = [
            (k, 0, 1, 0),
            (0, k, 0, 1),
            (0, 1, k, 0),
            (1, 0, 0, k),
        ]

        self.pad = nn.ModuleList(
            [nn.ZeroPad2d(p) for p in pads]
        )

        self.pre_norm = nn.GroupNorm(
            8, in_channels, eps=1e-4
        )

        self.conv_w = nn.Conv2d(
            in_channels,
            out_channels // 4,
            kernel_size=(1, k),
            stride=stride,
            padding=0,
            bias=False,
        )

        self.conv_h = nn.Conv2d(
            in_channels,
            out_channels // 4,
            kernel_size=(k, 1),
            stride=stride,
            padding=0,
            bias=False,
        )

        self.mid_norm = nn.GroupNorm(
            8, out_channels, eps=1e-4
        )

        self.fusion = nn.Conv2d(
            out_channels,
            out_channels,
            kernel_size=2,
            stride=1,
            padding=0,
            bias=False,
        )

        self.out_norm = nn.GroupNorm(
            8, out_channels, eps=1e-4
        )

        self.act = nn.ReLU6(inplace=True)

    def forward(self, x):
        x = self.pre_norm(x)

        x_w0 = self.conv_w(self.pad[0](x))
        x_w1 = self.conv_w(self.pad[1](x))
        x_h0 = self.conv_h(self.pad[2](x))
        x_h1 = self.conv_h(self.pad[3](x))

        x = torch.cat(
            [x_w0, x_w1, x_h0, x_h1],
            dim=1,
        )

        x = self.act(self.mid_norm(x))
        x = self.fusion(x)
        x = self.act(self.out_norm(x))

        return x
