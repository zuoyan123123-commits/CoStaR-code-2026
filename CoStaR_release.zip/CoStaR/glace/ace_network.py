# Copyright © Niantic, Inc. 2022.

import logging
import math
import re

import torch
import torch.nn as nn
import torch.nn.functional as F

_logger = logging.getLogger(__name__)


class Encoder(nn.Module):
    """
    FCN encoder, used to extract features from the input images.

    The number of output channels is configurable, the default used in the paper is 512.
    """

    def __init__(self, out_channels=512):
        super(Encoder, self).__init__()

        self.out_channels = out_channels

        self.conv1 = nn.Conv2d(1, 32, 3, 1, 1)
        self.conv2 = nn.Conv2d(32, 64, 3, 2, 1)
        self.conv3 = nn.Conv2d(64, 128, 3, 2, 1)
        self.conv4 = nn.Conv2d(128, 256, 3, 2, 1)

        self.res1_conv1 = nn.Conv2d(256, 256, 3, 1, 1)
        self.res1_conv2 = nn.Conv2d(256, 256, 1, 1, 0)
        self.res1_conv3 = nn.Conv2d(256, 256, 3, 1, 1)

        self.res2_conv1 = nn.Conv2d(256, 512, 3, 1, 1)
        self.res2_conv2 = nn.Conv2d(512, 512, 1, 1, 0)
        self.res2_conv3 = nn.Conv2d(512, self.out_channels, 3, 1, 1)

        self.res2_skip = nn.Conv2d(256, self.out_channels, 1, 1, 0)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        res = F.relu(self.conv4(x))

        x = F.relu(self.res1_conv1(res))
        x = F.relu(self.res1_conv2(x))
        x = F.relu(self.res1_conv3(x))

        res = res + x

        x = F.relu(self.res2_conv1(res))
        x = F.relu(self.res2_conv2(x))
        x = F.relu(self.res2_conv3(x))

        x = self.res2_skip(res) + x

        return x


class Head(nn.Module):
    """
    MLP network predicting per-pixel scene coordinates given a feature vector. All layers are 1x1 convolutions.
    """

    def __init__(self,
                 mean,
                 num_head_blocks,
                 use_homogeneous,
                 homogeneous_min_scale=0.01,
                 homogeneous_max_scale=4.0,
                 in_channels=512,
                 head_channels=512,
                 mlp_ratio=1.0
        ):
        super(Head, self).__init__()

        self.use_homogeneous = use_homogeneous
        self.in_channels = in_channels  # Number of encoder features.
        self.head_channels = head_channels

        # We may need a skip layer if the number of features output by the encoder is different.
        self.head_skip = nn.Identity() if self.in_channels == self.head_channels else nn.Conv2d(self.in_channels,
                                                                                                self.head_channels, 1,
                                                                                                1, 0)

        block_channels = int(self.head_channels * mlp_ratio)
        self.res3_conv1 = nn.Conv2d(self.in_channels, self.head_channels, 1, 1, 0)
        self.res3_conv2 = nn.Conv2d(self.head_channels, block_channels, 1, 1, 0)
        self.res3_conv3 = nn.Conv2d(block_channels, self.head_channels, 1, 1, 0)

        self.res_blocks = []

        for block in range(num_head_blocks):
            self.res_blocks.append((
                nn.Conv2d(self.head_channels, self.head_channels, 1, 1, 0),
                nn.Conv2d(self.head_channels, block_channels, 1, 1, 0),
                nn.Conv2d(block_channels, self.head_channels, 1, 1, 0),
            ))

            super(Head, self).add_module(str(block) + 'c0', self.res_blocks[block][0])
            super(Head, self).add_module(str(block) + 'c1', self.res_blocks[block][1])
            super(Head, self).add_module(str(block) + 'c2', self.res_blocks[block][2])

        self.fc1 = nn.Conv2d(self.head_channels, self.head_channels, 1, 1, 0)
        self.fc2 = nn.Conv2d(self.head_channels, block_channels, 1, 1, 0)
        self.use_position_decoder = mean.numel() > 3
        if self.use_position_decoder:
            self.fcc = nn.Conv2d(block_channels, mean.shape[0] , 1, 1, 0)

        if self.use_homogeneous:
            self.fc3 = nn.Conv2d(block_channels, 4, 1, 1, 0)

            # Use buffers because they need to be saved in the state dict.
            self.register_buffer("max_scale", torch.tensor([homogeneous_max_scale]))
            self.register_buffer("min_scale", torch.tensor([homogeneous_min_scale]))
            self.register_buffer("max_inv_scale", 1. / self.max_scale)
            self.register_buffer("h_beta", math.log(2) / (1. - self.max_inv_scale))
            self.register_buffer("min_inv_scale", 1. / self.min_scale)
        else:
            self.fc3 = nn.Conv2d(block_channels, 3, 1, 1, 0)

        # Learn scene coordinates relative to a mean coordinate (e.g. center of the scene).
        if self.use_position_decoder:
            self.register_buffer("centers", mean.clone().detach().view(1, mean.shape[0],3, 1, 1))
        else:
            self.register_buffer("mean", mean.clone().detach().view(1, 3, 1, 1))

    def forward(self, res):

        x = F.relu(self.res3_conv1(res))
        x = F.relu(self.res3_conv2(x))
        x = F.relu(self.res3_conv3(x))

        res = self.head_skip(res) + x

        for res_block in self.res_blocks:
            x = F.relu(res_block[0](res))
            x = F.relu(res_block[1](x))
            x = F.relu(res_block[2](x))

            res = res + x

        sc = F.relu(self.fc1(res))
        sc = F.relu(self.fc2(sc))
        mean = torch.sum(F.softmax(self.fcc(sc),dim=1).unsqueeze(2) * self.centers, dim=1, keepdim=False) if self.use_position_decoder else self.mean
        sc = self.fc3(sc)

        if self.use_homogeneous:
            # Dehomogenize coords:
            # Softplus ensures we have a smooth homogeneous parameter with a minimum value = self.max_inv_scale.
            h_slice = F.softplus(sc[:, 3, :, :].unsqueeze(1), beta=self.h_beta.item()) + self.max_inv_scale
            h_slice.clamp_(max=self.min_inv_scale)
            sc = sc[:, :3] / h_slice

        # Add the mean to the predicted coordinates.
        sc = sc + mean

        return sc


class PConv(nn.Module):
    """
    Coordinate Directional Spatial Mixing / PConv block.
    Four directional asymmetric branches + 2x2 fusion.
    Adapted for GLACE head replacement.
    """
    def __init__(self, c1, c2, k=3, s=1):
        super().__init__()
        assert c2 % 4 == 0, "PConv output channels must be divisible by 4"

        pads = [(k, 0, 1, 0), (0, k, 0, 1), (0, 1, k, 0), (1, 0, 0, k)]
        self.pad = nn.ModuleList([nn.ZeroPad2d(pad) for pad in pads])

        self.pre_norm = nn.GroupNorm(8, c1, eps=1e-4)

        self.cw = nn.Conv2d(c1, c2 // 4, (1, k), stride=s, padding=0, bias=False)
        self.ch = nn.Conv2d(c1, c2 // 4, (k, 1), stride=s, padding=0, bias=False)

        self.mid_norm = nn.GroupNorm(8, c2, eps=1e-4)
        self.cat = nn.Conv2d(c2, c2, 2, stride=1, padding=0, bias=False)
        self.out_norm = nn.GroupNorm(8, c2, eps=1e-4)

        self.act = nn.ReLU6(inplace=True)

    def forward(self, x):
        x = self.pre_norm(x)

        yw0 = self.cw(self.pad[0](x))
        yw1 = self.cw(self.pad[1](x))
        yh0 = self.ch(self.pad[2](x))
        yh1 = self.ch(self.pad[3](x))

        out = torch.cat([yw0, yw1, yh0, yh1], dim=1)
        out = self.act(self.mid_norm(out))
        out = self.cat(out)
        out = self.act(self.out_norm(out))
        return out


class UARHead(Head):
    """
    GLACE-compatible C-DSM/UAR-PConv head.

    It keeps the original GLACE coarse coordinate head and position decoder,
    then adds an uncertainty-guided PConv/C-DSM refinement branch:
        coarse = GLACE position-decoded coordinate
        sigma  = uncertainty branch from shared feature
        attn   = sigmoid(-sigma / temperature)
        offset = C-DSM refinement branch
        output = coarse + offset
    """
    def __init__(self,
                 mean,
                 num_head_blocks,
                 use_homogeneous,
                 homogeneous_min_scale=0.01,
                 homogeneous_max_scale=4.0,
                 in_channels=512,
                 head_channels=512,
                 mlp_ratio=1.0,
                 refine_channels=128,
                 temperature=3.0):
        super().__init__(
            mean=mean,
            num_head_blocks=num_head_blocks,
            use_homogeneous=use_homogeneous,
            homogeneous_min_scale=homogeneous_min_scale,
            homogeneous_max_scale=homogeneous_max_scale,
            in_channels=in_channels,
            head_channels=head_channels,
            mlp_ratio=mlp_ratio,
        )

        self.temperature = temperature
        block_channels = int(self.head_channels * mlp_ratio)

        self.unc_fc = nn.Sequential(
            nn.Conv2d(block_channels, 128, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 1, 1),
        )
        self.softplus = nn.Softplus(beta=1.0)

        nn.init.zeros_(self.unc_fc[2].weight)
        nn.init.constant_(self.unc_fc[2].bias, 0.54)

        # In this direct GLACE-CDSM migration, sigma has no dedicated loss yet.
        # Full CoStaR: train uncertainty branch with uncertainty loss.
        for p in self.unc_fc.parameters():
            p.requires_grad_(True)

        self.refine_net = nn.Sequential(
            nn.Conv2d(block_channels, refine_channels, 1, bias=False),
            nn.GroupNorm(8, refine_channels, eps=1e-4),
            nn.ReLU6(inplace=True),
            PConv(refine_channels, refine_channels, k=3),
            nn.GroupNorm(8, refine_channels, eps=1e-4),
            nn.ReLU6(inplace=True),
            nn.Conv2d(refine_channels, 3, 1),
            nn.Hardtanh(min_val=-2.0, max_val=2.0, inplace=True),
        )

        # Start as original GLACE head: initial offset is zero.
        nn.init.zeros_(self.refine_net[6].weight)
        nn.init.zeros_(self.refine_net[6].bias)

    def _shared_forward(self, res):
        x = F.relu(self.res3_conv1(res))
        x = F.relu(self.res3_conv2(x))
        x = F.relu(self.res3_conv3(x))

        shared = self.head_skip(res) + x

        for res_block in self.res_blocks:
            x = F.relu(res_block[0](shared))
            x = F.relu(res_block[1](x))
            x = F.relu(res_block[2](x))
            shared = shared + x

        fc_out = F.relu(self.fc1(shared))
        fc_out = F.relu(self.fc2(fc_out))
        return fc_out

    def _coarse_from_fc(self, fc_out):
        # Keep GLACE position decoder.
        mean = (
            torch.sum(
                F.softmax(self.fcc(fc_out), dim=1).unsqueeze(2) * self.centers,
                dim=1,
                keepdim=False,
            )
            if self.use_position_decoder
            else self.mean
        )

        coarse = self.fc3(fc_out)

        if self.use_homogeneous:
            h_slice = F.softplus(
                coarse[:, 3, :, :].unsqueeze(1),
                beta=self.h_beta.item()
            ) + self.max_inv_scale
            h_slice.clamp_(max=self.min_inv_scale)
            coarse = coarse[:, :3] / h_slice

        coarse = coarse + mean
        return coarse

    def forward(self, res):
        fc_out = self._shared_forward(res)

        coarse = self._coarse_from_fc(fc_out)

        # Keep the clean_only behavior: sigma branch does not destabilize coordinate regression.
        sigma = self.softplus(self.unc_fc(fc_out.detach())) + 0.01
        sigma = sigma.clamp(max=10.0)
        attention = torch.sigmoid(-sigma.detach() / self.temperature)

        offset = self.refine_net(fc_out * attention)
        refined = coarse + offset

        return refined

    def forward_with_all(self, res):
        fc_out = self._shared_forward(res)

        coarse = self._coarse_from_fc(fc_out)

        sigma = self.softplus(self.unc_fc(fc_out.detach())) + 0.01
        sigma = sigma.clamp(max=10.0)
        attention = torch.sigmoid(-sigma.detach() / self.temperature)

        offset = self.refine_net(fc_out * attention)
        refined = coarse + offset

        return refined, coarse, sigma, attention


class Regressor(nn.Module):
    """
    FCN architecture for scene coordinate regression.

    The network predicts a 3d scene coordinates, the output is subsampled by a factor of 8 compared to the input.
    """

    OUTPUT_SUBSAMPLE = 8

    def __init__(self, mean, num_head_blocks, use_homogeneous, num_encoder_features=512,num_decoder_features=512,
                head_channels=512,mlp_ratio=1.0):
        """
        Constructor.

        mean: Learn scene coordinates relative to a mean coordinate (e.g. the center of the scene).
        num_head_blocks: How many extra residual blocks to use in the head (one is always used).
        use_homogeneous: Whether to learn homogeneous or 3D coordinates.
        num_encoder_features: Number of channels output of the encoder network.
        """
        super(Regressor, self).__init__()

        self.feature_dim = num_encoder_features
        self.decoder_dim = num_decoder_features

        self.encoder = Encoder(out_channels=self.feature_dim)
        self.heads = UARHead(mean, num_head_blocks, use_homogeneous, in_channels=num_decoder_features, head_channels=head_channels, mlp_ratio=mlp_ratio)

    @classmethod
    def create_from_encoder(cls, encoder_state_dict, mean, num_head_blocks, use_homogeneous,global_feat_dim=0,head_channels=512,mlp_ratio=1.0):
        """
        Create a regressor using a pretrained encoder, loading encoder-specific parameters from the state dict.

        encoder_state_dict: pretrained encoder state dictionary.
        mean: Learn scene coordinates relative to a mean coordinate (e.g. the center of the scene).
        num_head_blocks: How many extra residual blocks to use in the head (one is always used).
        use_homogeneous: Whether to learn homogeneous or 3D coordinates.
        """

        # Number of output channels of the last encoder layer.
        num_encoder_features = encoder_state_dict['res2_conv3.weight'].shape[0]

        # Create a regressor.
        _logger.info(f"Creating Regressor using pretrained encoder with {num_encoder_features} feature size.")
        regressor = cls(mean, num_head_blocks, use_homogeneous, num_encoder_features,num_encoder_features+ global_feat_dim,
                    head_channels=head_channels,mlp_ratio=mlp_ratio)

        # Load encoder weights.
        regressor.encoder.load_state_dict(encoder_state_dict)

        # Done.
        return regressor

    @classmethod
    def create_from_state_dict(cls, state_dict):
        """
        Instantiate a regressor from a pretrained state dictionary.

        state_dict: pretrained state dictionary.
        """
        # Mean is zero (will be loaded from the state dict).
        if "heads.centers" in state_dict:
            mean = torch.zeros((state_dict["heads.centers"].shape[1],3))
        else:
            mean = torch.zeros((3,))

        # Count how many head blocks are in the dictionary.
        pattern = re.compile(r"^heads\.\d+c0\.weight$")
        num_head_blocks = sum(1 for k in state_dict.keys() if pattern.match(k))

        # Whether the network uses homogeneous coordinates.
        use_homogeneous = state_dict["heads.fc3.weight"].shape[0] == 4

        # Number of output channels of the last encoder layer.
        num_encoder_features = state_dict['encoder.res2_conv3.weight'].shape[0]
        num_decoder_features = state_dict['heads.res3_conv1.weight'].shape[1]
        head_channels =  state_dict['heads.res3_conv1.weight'].shape[0]
        mlp_ratio = state_dict['heads.res3_conv2.weight'].shape[0]/state_dict['heads.res3_conv2.weight'].shape[1]

        # Create a regressor.
        _logger.info(f"Creating regressor from pretrained state_dict:"
                     f"\n\tNum head blocks: {num_head_blocks}"
                     f"\n\tHomogeneous coordinates: {use_homogeneous}"
                     f"\n\tEncoder feature size: {num_encoder_features}"
                     f"\n\tDecoder feature size: {num_decoder_features}"
                     f"\n\tHead channels: {head_channels}"
                     f"\n\tMLP ratio: {mlp_ratio}")
        regressor = cls(mean, num_head_blocks, use_homogeneous, num_encoder_features,num_decoder_features,
                        head_channels=head_channels,mlp_ratio=mlp_ratio)

        # Load all weights.
        regressor.load_state_dict(state_dict)

        # Done.
        return regressor

    @classmethod
    def create_from_split_state_dict(cls, encoder_state_dict, head_state_dict):
        """
        Instantiate a regressor from a pretrained encoder (scene-agnostic) and a scene-specific head.

        encoder_state_dict: encoder state dictionary
        head_state_dict: scene-specific head state dictionary
        """
        # We simply merge the dictionaries and call the other constructor.
        merged_state_dict = {}

        for k, v in encoder_state_dict.items():
            merged_state_dict[f"encoder.{k}"] = v

        for k, v in head_state_dict.items():
            merged_state_dict[f"heads.{k}"] = v

        return cls.create_from_state_dict(merged_state_dict)

    def load_encoder(self, encoder_dict_file):
        """
        Load weights into the encoder network.
        """
        self.encoder.load_state_dict(torch.load(encoder_dict_file))

    def get_features(self, inputs):
        return self.encoder(inputs)

    def get_scene_coordinates(self, features):
        return self.heads(features)

    def forward(self, inputs,global_feats):
        """
        Forward pass.
        """
        features = self.get_features(inputs)
        if self.feature_dim != self.decoder_dim:
            features = torch.cat((global_feats[...,None,None].expand(-1,-1,features.shape[2],features.shape[3]) ,features),dim=1)
        return self.get_scene_coordinates(features)
