#!/usr/bin/env bash
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

SCENE=${1:-/path/to/dataset/7scenes_stairs}
OUTPUT=${2:-outputs/7scenes_stairs_costar.pt}

python "$ROOT/train.py" \
    "$SCENE" \
    "$OUTPUT" \
    --config "$ROOT/configs/glace_default.json"
