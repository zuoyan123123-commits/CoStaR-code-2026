#!/usr/bin/env bash
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ "$#" -lt 2 ]; then
    echo "Usage:"
    echo "  bash scripts/extract_features.sh SCENE GLOBAL_FEATURE_CHECKPOINT"
    exit 1
fi

SCENE="$1"
CHECKPOINT="$2"

python "$ROOT/glace/datasets/extract_features.py" \
    "$SCENE" \
    --checkpoint "$CHECKPOINT"
